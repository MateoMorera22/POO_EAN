/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package peatones;

import javax.swing.JOptionPane;

/**
 *
 * @author SALA
 */
public class Peaton extends Persona {

    public Peaton(String nombre, String genero, int edad) {
        super(nombre, genero, edad);
    }
    /**
     *
     * @param entradaSaludo
     */
    @Override
    public void saludar(String entradaSaludo) {
        JOptionPane.showMessageDialog(null," "
                + "El peaton camina y te saluda diciendo:" +entradaSaludo);
    }
    
    public void caminar(boolean entradaCaminar){
        int pasosMaximos= 100;
        if(entradaCaminar == true){
         for(int i = 0; i<pasosMaximos;i++ ){
             System.out.println("Caminando..., numero de pasos: " +i);
         }
         
        }else{System.out.println("Mucha pereza..");}
                  
    }
    
      public void caminar(boolean entradaCaminar,int entradaVelocidad){
          if(entradaCaminar==true){
        int pasosMaximos= 2000;
         for(int i = 0; i<pasosMaximos;i++ ){
             int pasos = i*entradaVelocidad;
             System.out.println("Caminando..., numero de pasos: " +pasos);
         }       
                  
          }else{
              System.out.println("Parece que no tienes ganas de correr");
          }
    }
    
}
