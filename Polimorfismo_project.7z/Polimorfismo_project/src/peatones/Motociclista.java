/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package peatones;

import javax.swing.JOptionPane;

/**
 *
 * @author SALA
 */
public class Motociclista extends Persona{

    
     private String placa;
    
    public Motociclista(String nombre, String genero, int edad, String placa) {
        super(nombre, genero, edad);
        this.placa = placa;
    }

    @Override
    public void saludar(String entradaSaludo) {
        JOptionPane.showMessageDialog(null," "
                + "El motocilcista con la placa: " + this.placa + "Parquea "
                        + "y te saluda diciendo: " +entradaSaludo);
    }

    }
    

