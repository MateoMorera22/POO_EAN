
import peatones.Motociclista;
import peatones.Peaton;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */

/**
 *
 * @author SALA
 */
public class main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
       
        Peaton peaton1 = new Peaton("Mateo","M",22);
        Motociclista moto1 = new Motociclista("Pedro","M",40,"XYRMJJ");

       //peaton1.saludar("Hola soy un peaton como estas?");
       //moto1.saludar("Hola que tal...");
        
        peaton1.caminar(true);
        //peaton1.caminar(true,3);
        
        
    }
    
}
